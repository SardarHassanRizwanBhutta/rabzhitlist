globalThis.__BUILD_MANIFEST = {
  "pages": {
    "/_app": [
      "static/chunks/e60ef129113f6e24.js",
      "static/chunks/f5ee1cc7d6044fd1.js",
      "static/chunks/turbopack-dd2e5be54c3747d5.js"
    ],
    "/_error": [
      "static/chunks/17722e3ac4e00587.js",
      "static/chunks/f5ee1cc7d6044fd1.js",
      "static/chunks/turbopack-bc56a26c534b2f13.js"
    ]
  },
  "devFiles": [],
  "ampDevFiles": [],
  "polyfillFiles": [
    "static/chunks/a6dad97d9634a72d.js"
  ],
  "lowPriorityFiles": [],
  "rootMainFiles": [
    "static/chunks/c85a7d07e7b82c9a.js",
    "static/chunks/2008ffcf9e5b170c.js",
    "static/chunks/1157cb2e3ce5426a.js",
    "static/chunks/30cb146bc1e6f45f.js",
    "static/chunks/8082ab48faca5ea1.js",
    "static/chunks/turbopack-5bdfb7667088e8d3.js"
  ],
  "ampFirstPages": []
};
globalThis.__BUILD_MANIFEST.lowPriorityFiles = [
"/static/" + process.env.__NEXT_BUILD_ID + "/_buildManifest.js",
,"/static/" + process.env.__NEXT_BUILD_ID + "/_ssgManifest.js",

];