__turbopack_load_page_chunks__("/_error", [
  "static/chunks/17722e3ac4e00587.js",
  "static/chunks/f5ee1cc7d6044fd1.js",
  "static/chunks/turbopack-bc56a26c534b2f13.js"
])
